#include <stdio.h>

int diferenca(int A[], int tamA, int B[], int tamB) {
    int i, j;
    int encontrou;
    int diferencaEncontrada = 0;

    for (i = 0; i < tamA; i++) {
        encontrou = 0;
        for (j = 0; j < tamB; j++) {
            if (A[i] == B[j]) {
                encontrou = 1;
                break;
            }
        }
        if (!encontrou) {
            printf("%d ", A[i]);
            diferencaEncontrada = 1;
        }
    }
    printf("\n");

    return diferencaEncontrada;
}

int main() {
    int A[] = {7, 2, 5, 8, 4};
    int tamA = sizeof(A) / sizeof(A[0]);
    int B[] = {4, 2, 9, 5};
    int tamB = sizeof(B) / sizeof(B[0]);

    printf("A - B = ");
    int difA_B = diferenca(A, tamA, B, tamB);

    int C[] = {3, 9, 11};
    int tamC = sizeof(C) / sizeof(C[0]);
    int D[] = {2, 6, 1};
    int tamD = sizeof(D) / sizeof(D[0]);

    printf("C - D = ");
    int difC_D = diferenca(C, tamC, D, tamD);

    return 0;
}