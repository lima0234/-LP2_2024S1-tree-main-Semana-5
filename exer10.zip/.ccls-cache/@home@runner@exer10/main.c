#include <stdio.h>

int uniao(int A[], int tamA, int B[], int tamB) {
    int i, j;
    int encontrou = 0;

    for (i = 0; i < tamA; i++) {
        printf("%d ", A[i]);
    }

    for (i = 0; i < tamB; i++) {
        encontrou = 0;
        for (j = 0; j < tamA; j++) {
            if (B[i] == A[j]) {
                encontrou = 1;
                break;
            }
        }
        if (!encontrou) {
            printf("%d ", B[i]);
        }
    }
    printf("\n");

    return 0;
}

int main() {
    int A[] = {7, 2, 5, 8, 4};
    int tamA = sizeof(A) / sizeof(A[0]);
    int B[] = {4, 2, 9, 5};
    int tamB = sizeof(B) / sizeof(B[0]);

    printf("A ∪ B = ");
    uniao(A, tamA, B, tamB);

    int C[] = {3, 9, 11};
    int tamC = sizeof(C) / sizeof(C[0]);
    int D[] = {2, 6, 1};
    int tamD = sizeof(D) / sizeof(D[0]);

    printf("C ∪ D = ");
    uniao(C, tamC, D, tamD);

    return 0;
}